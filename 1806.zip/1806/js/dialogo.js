function base64ToUtf8(b64) {
    const binaryString = atob(b64);

    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }

    const decoder = new TextDecoder();
    return decoder.decode(bytes);
}

const deleteModal = document.getElementById("excluirModal");

// Evento disparado quando o modal começa a ser exibido
deleteModal.addEventListener('show.bs.modal', (event) => {

    const button = event.relatedTarget;

    const modalBody = deleteModal.querySelector(".modal-body");
    const modalTitle = deleteModal.querySelector(".modal-title");
    const confirmDelete = document.getElementById("confirmar");

    // ID em base64 (para exclusão)
    var idParaExcluir = button.getAttribute('data-produto');

    // ID decodificado para exibição
    var idParaExibir = base64ToUtf8(button.getAttribute('data-produto'));

    modalTitle.innerHTML = "Apagando Médico: " + idParaExibir;

    modalBody.innerHTML = "Deseja mesmo apagar o registro " + idParaExibir + "?";

    confirmDelete.setAttribute("href", "excluir.php?id=" + idParaExcluir);
});