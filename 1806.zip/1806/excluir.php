<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excluir</title>

    <link rel="icon" type="image/icon" href="img/icon.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/estilo.css">

    <style>
        .foto {
            width: 150px;
        }
    </style>
</head>

<body>
    <main class="container">
        <?php
        try {
            include "conexao.php";

            // Recuperando a informação da URL
            // Verifica se o parâmetro está correto
            if (
                isset($_GET['id']) &&
                is_numeric(base64_decode($_GET['id']))
            ) {
                $id = base64_decode($_GET['id']);
            } else {
                header("Location: index.php");
                exit;
            }

            // Criando a instrução DELETE
            $sql = "DELETE FROM tabelaimg WHERE id = $id";

            // Executando instrução SQL
            $resultado = $conexao->query($sql);

            echo "
                <script>
                    alert('Médico excluído com sucesso!');
                    window.location = 'index.php';
                </script>
            ";
        } catch (Exception $e) {
            echo "
                <script>
                    alert('Erro: {$e->getMessage()}');
                    window.location = 'index.php';
                </script>
            ";
        }
        ?>
    </main>
</body>

</html>