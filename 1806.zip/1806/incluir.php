<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Incluir</title>

    <link rel="icon" type="image/icon" href="img/icon.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/estilo.css">

    <style>
        .foto {
            width: 220px;
            max-width: 100%;
        }

        .card {
            border-radius: 12px;
        }
    </style>
</head>

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    try {

        include "conexao.php";

        // recuperando
        $codigo = $_POST['codigo'];
        $produto = $_POST['produto'];
        $descricao = $_POST['descricao'];
        $data = $_POST['data'];
        $valor = $_POST['valor'];

        $target_dir = "img/";
        $target_file = $target_dir . basename($_FILES["foto"]["name"]);
        $arquivo = basename($_FILES["foto"]["name"]);

        // criando a linha de INSERT
        $sql = "insert into tabelaimg
                (codigo, produto, descricao, data, valor, imagem)
                values
                ('$codigo', '$produto', '$descricao', '$data', $valor, '$arquivo')";

        $resultado = $conexao->query($sql);

        if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {

            $mensagem = "The file " .
                htmlspecialchars(basename($_FILES["foto"]["name"])) .
                " has been uploaded.";

        } else {

            $mensagem = "Sorry, there was an error uploading your file.";
        }

        echo "
<script>
    alert('Médico cadastrado com sucesso!');
    window.location='index.php';
</script>
";

    } catch (Exception $e) {

        echo "
<script>
    alert('Erro: {$e->getMessage()}');
    window.location='incluir.php';
</script>
";
    }
}

?>

<body>

    <header class="topo container-fluid px-lg-5 px-3">

        <div class="marca d-flex align-items-center">
            <img src="img/logo.png" alt="Logo" class="logo img-fluid">
        </div>

        <nav class="d-flex align-items-center flex-wrap justify-content-center">
            <a href="#cadastrar">Cadastrar</a>
            <a href="#sec-preview">Preview</a>
            <a href="#info">Informações</a>

            <a class="btn-nav"
                href="https://en.wikipedia.org/wiki/Grey%27s_Anatomy">
                SAIBA MAIS
            </a>
        </nav>

    </header>

    <div class="container-fluid p-3 mb-2 breadcrumb-container">

        <nav aria-label="breadcrumb">

            <ol class="breadcrumb fs-5">
                <li class="breadcrumb-item">
                    <a href="index.php">Início</a>
                </li>

                <li class="breadcrumb-item">
                    <a href="incluir.php">Incluir</a>
                </li>
            </ol>

        </nav>

    </div>

    <main class="container">

        <h3 class="mb-4">Cadastrar Médico</h3>

        <div class="card neutro shadow-sm p-4 mb-4">

            <form name="produto"
                action="incluir.php"
                method="post"
                enctype="multipart/form-data">

                <div class="mb-3" id="cadastrar">
                    <label for="codigo" class="form-label">
                        <strong>Código</strong>
                    </label>

                    <input type="number"
                        class="form-control"
                        id="codigo"
                        name="codigo"
                        required>
                </div>

                <div class="mb-3">
                    <label for="produto" class="form-label">
                        <strong>Médico</strong>
                    </label>

                    <input type="text"
                        class="form-control"
                        id="produto"
                        name="produto"
                        maxlength="80">
                </div>

                <div class="mb-3">
                    <label for="descricao" class="form-label">
                        <strong>Descrição</strong>
                    </label>

                    <textarea class="form-control"
                        id="descricao"
                        name="descricao"
                        rows="4"></textarea>
                </div>

                <div class="row">

                    <div class="col-md-6 mb-3">
                        <label for="data" class="form-label">
                            <strong>Data de Cadastro</strong>
                        </label>

                        <input type="date"
                            class="form-control"
                            id="data"
                            name="data">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="valor" class="form-label">
                            <strong>Salário (R$)</strong>
                        </label>

                        <input type="number"
                            class="form-control"
                            id="valor"
                            name="valor"
                            step="0.01">
                    </div>

                </div>

                <div class="mb-3" id="sec-preview">
                    <label for="imagemnova" class="form-label">
                        <strong>Imagem</strong>
                    </label>

                    <input type="file"
                        class="form-control"
                        name="foto"
                        id="imagemnova"
                        accept="image/*">
                </div>

                <div class="text-center mb-4">

                    <p class="fw-bold">Pré-visualização</p>

                    <img src="img/SemImagem.png"
                        id="preview"
                        class="img-thumbnail shadow foto"
                        alt="Sem imagem">

                </div>

                <div class="d-flex gap-2 justify-content-end">

                    <input type="reset"
                        class="btn btn-secondary"
                        value="Limpar">

                    <a href="index.php" class="btn btn-azul">
                        Cancelar
                    </a>

                    <input type="submit"
                        class="btn btn-dark"
                        value="Salvar">

                </div>

            </form>

        </div>

    </main>

    <script>
        document.getElementById('imagemnova').addEventListener('change', function(event) {

            const file = event.target.files[0];

            const reader = new FileReader();

            reader.onload = function(e) {

                const img = document.getElementById('preview');
                img.src = e.target.result;

            };

            reader.readAsDataURL(file);

        });
    </script>

    <footer class="footer" id="info">

        <div class="footer-top">

            <div class="footer-logo">
                <img src="img/logo.png" alt="logo">
            </div>

            <div class="footer-info">
                <h4>Beatriz Andrade Vasconcelos</h4>
                <h4>Gustavo Freitas Pereira</h4>
            </div>

        </div>

        <hr>

        <div class="footer-bottom">
            © Cadastros dos Médicos - 2026
        </div>

    </footer>

</body>

</html>