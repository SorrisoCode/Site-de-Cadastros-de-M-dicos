SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET NAMES utf8;

CREATE DATABASE IF NOT EXISTS banco2;
USE banco2;

CREATE TABLE IF NOT EXISTS tabelaimg (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    codigo INT NOT NULL,
    produto VARCHAR(80) NOT NULL,
    descricao VARCHAR(250) NOT NULL,
    data DATETIME NOT NULL,
    valor FLOAT NOT NULL,
    imagem VARCHAR(50)
) DEFAULT CHARSET=utf8;

INSERT INTO tabelaimg
(codigo, produto, descricao, data, valor, imagem)
VALUES

(1001, 'Meredith Grey',
'Médica especialista em Cirurgia Geral, com ampla experiência em procedimentos de alta complexidade e atendimento hospitalar.',
'2005-03-27', 25000.00, 'Meredith.jpeg'),

(1002, 'Derek Shepherd',
'Médico neurocirurgião com atuação em cirurgias cerebrais e tratamento de doenças do sistema nervoso central.',
'2005-03-27', 30000.00, 'Derek.jpeg'),

(1003, 'Cristina Yang',
'Médica cardiologista cirúrgica especializada em intervenções cardiovasculares e acompanhamento de pacientes cardíacos.',
'2005-03-27', 28000.00, 'Cristina.jpeg'),

(1004, 'Miranda Bailey',
'Médica especialista em Cirurgia Geral e gestão hospitalar, responsável pela coordenação de equipes médicas.',
'2005-03-27', 27000.00, 'Miranda.jpeg'),

(1005, 'Alex Karev',
'Médico pediatra dedicado ao atendimento infantil, prevenção de doenças e acompanhamento do desenvolvimento infantil.',
'2005-03-27', 22000.00, 'Alex.jpeg'),

(1006, 'Richard Webber',
'Médico cirurgião com extensa experiência clínica e atuação na formação e supervisão de profissionais da saúde.',
'2005-03-27', 32000.00, 'Richard.jpg'),

(1007, 'Arizona Robbins',
'Médica pediatra especializada em cirurgia pediátrica, com foco no tratamento cirúrgico de crianças e adolescentes.',
'2005-03-27', 29000.00, 'Arizona.jpg'),

(1008, 'Callie Torres',
'Médica ortopedista especialista em tratamento de lesões ósseas, articulares e reabilitação musculoesquelética.',
'2005-03-27', 28500.00, 'Callie.jpg'),

(1009, 'Jackson Avery',
'Médico cirurgião plástico com experiência em procedimentos reconstrutivos e estéticos de alta complexidade.',
'2005-03-27', 29500.00, 'Jackson.jpg'),

(1010, 'April Kepner',
'Médica especialista em Medicina de Emergência e Trauma, atuando no atendimento de pacientes em estado crítico.',
'2005-03-27', 26000.00, 'April.jpeg');
