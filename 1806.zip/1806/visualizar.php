<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualizar</title>

    <link rel="icon" type="image/icon" href="img/icon.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/estilo.css">

    <style>
        .foto {
            width: 200px;
        }
    </style>
</head>

<body>

    <header class="topo container-fluid px-lg-5 px-3">

        <div class="marca d-flex align-items-center">
            <img src="img/logo.png" alt="Logo" class="logo img-fluid">
        </div>

        <nav class="d-flex align-items-center flex-wrap justify-content-center">
            <a href="#card">Card</a>
            <a href="#descricao">Descrição</a>
            <a href="#sec-info">Informações</a>

            <a class="btn-nav"
                href="https://en.wikipedia.org/wiki/Grey%27s_Anatomy">
                SAIBA MAIS
            </a>
        </nav>

    </header>

    <div class="container-fluid p-3 mb-2 breadcrumb-container">

        <nav aria-label="breadcrumb">

            <ol class="breadcrumb fs-5">

                <li class="breadcrumb-item">
                    <a href="index.php">Início</a>
                </li>

                <li class="breadcrumb-item">
                    <a href="visualizar.php?id=Mg==">Visualizar</a>
                </li>

            </ol>

        </nav>

    </div>

    <main class="container">

        <h3>Descrição</h3>

        <?php

        try {

            include "conexao.php";

            function convertedata2ss($data)
            {
                $novadata = substr($data, 8, 2) . '/' . substr($data, 5, 2) . '/' . substr($data, 0, 4);
                return $novadata;
            }

            function convertedata($data)
            {
                $data_vetor = explode('-', $data);
                $novadata = implode('/', array_reverse($data_vetor));
                return $novadata;
            }

            // recuperando a informação da URL
            // verifica se parâmetro está correto e dento da normalidade
            if (isset($_GET['id']) && is_numeric(base64_decode($_GET['id']))) {
                $id = base64_decode($_GET['id']);
            } else {
                //ob_start(); // Inicia o Output Buffer
                header("Location: index.php");
            }

            // ajustando a instrução select para ordenar por produto
            //$query = mysqli_query($conexao, "select * from tabelaimg order by produto");
            $sql = "select * from tabelaimg where id = $id";
            $query = $conexao->query($sql);

            if ($query->num_rows > 0) {

                $dados = $query->fetch_assoc(); //  mysqli_fetch_array($query);

                $produto = $dados["produto"];
                $codigo = $dados["codigo"];
                $descricao = $dados["descricao"];

                $dt = new DateTime(
                    $dados["data"],
                    new DateTimeZone("America/Sao_Paulo")
                );

                $data = $dt->format("d/m/Y");
                $valor = "R$ " . number_format($dados["valor"], 2, ",", ".");

                // buscando a na pasta imagem
                if (empty($dados['imagem'])) {
                    $imagem = "SemImagem.png";
                } else {
                    $imagem = $dados['imagem'];
                }

            } else {

                throw new Exception("Médico não encontrado!");

            }

        } catch (Exception $e) {

            echo "<div class=\"alert alert-danger alert-dismissible fade show\" role=\"alert\">\n
                    <h2>Aconteceu um erro:<br>\n
                        {$e->getMessage()}\n
                    </h2>\n
                    <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\" aria-label=\"Close\"></button>\n
                </div>\n
                <a href=\"index.php\" class=\"btn btn-primary\">Voltar</a>\n";

        }

        ?>

        <?php if (!empty($codigo)): ?>

            <div class="row justify-content-center" id="card">

                <div class="col-md-6 col-lg-4 col-xl-4">

                    <div class="card shadow" style="max-width: 380px; margin: 0 auto;">

                        <img src="img/<?php echo $imagem; ?>"
                            class="img-thumbnail img-fluid"
                            alt="<?php echo $produto; ?>">

                        <div class="card-body">

                            <h5 class="card-title">
                                <?php echo $produto; ?>
                            </h5>

                            <p class="card-text">
                                <?php echo "Código: $codigo"; ?>
                            </p>

                            <p class="card-text" id="descricao">
                                <?php echo $descricao; ?>
                            </p>

                            <p class="card-text">
                                <?php echo $data; ?>
                            </p>

                            <p class="card-text">
                                <?php echo $valor; ?>
                            </p>

                            <a href="index.php" class="btn btn-azul btn-voltar">
                                Voltar
                            </a>

                        </div>

                    </div>

                </div>

            </div>

        <?php endif; ?>

    </main>

    <footer class="footer" id="sec-info">

        <div class="footer-top">

            <div class="footer-logo">
                <img src="img/logo.png" alt="logo">
            </div>

            <div class="footer-info">
                <h4>Beatriz Andrade Vasconcelos</h4>
                <h4>Gustavo Freitas Pereira</h4>
            </div>

        </div>

        <hr>

        <div class="footer-bottom">
            © Cadastros dos Médicos - 2026
        </div>

    </footer>

    <script src="js/bootstrap.bundle.min.js"></script>

</body>

</html>