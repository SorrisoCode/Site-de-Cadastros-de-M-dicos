<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar</title>
    <link rel="icon" type="image/icon" href="img/icon.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/estilo.css">
    <style>
        .foto {
            width: 150px;
        }
    </style>
</head>

<?php
try {
    include "conexao.php";

    // recuperando a informação da URL
    // verifica se parâmetro está correto e dento da normalidade
    if (isset($_GET['id']) && is_numeric(base64_decode($_GET['id']))) {
        $id = base64_decode($_GET['id']);
    } else {
        //ob_start(); // Inicia o Output Buffer
        throw new Exception("Médico não existe!");
        //header("Location: index.php");
    }

    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        // criando a linha do  SELECT
        $sql = "select * from tabelaimg where id = $id";
        $resultado = $conexao->query($sql);
        $dados = $resultado->fetch_assoc();

        $codigo = $dados['codigo'];
        $produto = $dados['produto'];
        $descricao = $dados['descricao'];
        $dt = new DateTime($dados['data'], new DateTimeZone("America/Sao_Paulo"));
        $data = $dt->format("Y-m-d");
        $valor = $dados['valor'];
    } else {
        // recuperando
        $codigo = $_POST['codigo'];
        $produto = $_POST['produto'];
        $descricao = $_POST['descricao'];
        $data = $_POST['data'];
        $valor = $_POST['valor'];

        // criando a linha de UPDATE
        $sql = "update tabelaimg set produto='" . htmlspecialchars($produto) .
            "', descricao='" . htmlspecialchars($descricao) . "', data='$data', valor=$valor, codigo=$codigo where id=$id";
        $resultado = $conexao->query($sql);

        echo "
<script>
    alert('Registro atualizado com sucesso!');
    window.location='index.php';
</script>
";
    }
} catch (Exception $e) {
    echo "
<script>
    alert('Erro: {$e->getMessage()}');
    window.location='editar.php?id=$id';
</script>
";
}

?>

<body>

    <header class="topo container-fluid px-lg-5 px-3">
        <div class="marca d-flex align-items-center">
            <img src="img/logo.png" alt="Logo" class="logo img-fluid">
        </div>

        <nav class="d-flex align-items-center flex-wrap justify-content-center">
            <a href="#editar">Editar</a>
            <a href="#foto">Foto</a>
            <a href="#sec-info">Informações</a>
            <a class="btn-nav" href="https://en.wikipedia.org/wiki/Grey%27s_Anatomy">SAIBA MAIS</a>
        </nav>
    </header>

    <div class="container-fluid p-3 mb-2 breadcrumb-container" id="editar">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb fs-5">
                <li class="breadcrumb-item">
                    <a href="index.php">Início</a>
                </li>
                <li class="breadcrumb-item">
                    <a href="editar.php?id=Mg==">Editar</a>
                </li>
            </ol>
        </nav>
    </div>

    <main class="container">
        <h3 class="mb-4">Editar Registro</h3>

        <?php $id = base64_encode($id); ?>

        <div class="card neutro shadow-sm p-4 mb-4">
            <form name="produto" action="editar.php?id=<?= $id; ?>" method="post" enctype="multipart/form-data">

                <div class="mb-3">
                    <label for="codigo" class="form-label"><strong>Código</strong></label>
                    <input type="number" class="form-control" id="codigo" name="codigo"
                        required value="<?php echo $codigo; ?>">
                </div>

                <div class="mb-3">
                    <label for="produto" class="form-label"><strong>Médico</strong></label>
                    <input type="text" class="form-control" id="produto" name="produto"
                        maxlength="80" value="<?php echo $produto; ?>">
                </div>

                <div class="mb-3">
                    <label for="descricao" class="form-label"><strong>Descrição</strong></label>
                    <textarea class="form-control" id="descricao" name="descricao"
                        rows="4"><?php echo $descricao; ?></textarea>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="data" class="form-label"><strong>Data de Cadastro</strong></label>
                        <input type="date" class="form-control" id="data" name="data"
                            value="<?php echo $data; ?>">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="valor" class="form-label"><strong>Salário (R$)</strong></label>
                        <input type="number" class="form-control" id="valor" name="valor"
                            step="0.01" value="<?php echo $valor; ?>">
                    </div>
                </div>

                <!-- FOTO ATUAL -->
                <?php if (!empty($dados['imagem'])) { ?>
                    <div class="mb-3 text-center">
                        <label class="form-label"><strong>Foto atual</strong></label><br>
                        <img src="img/<?php echo $dados['imagem']; ?>" class="foto mb-3" alt="Foto atual">
                    </div>
                <?php } ?>

                <!-- NOVA FOTO -->
                <div class="mb-3 text-center">
                    <label for="foto" class="form-label"><strong>Alterar Foto</strong></label>
                    <input type="file" class="form-control" id="foto" name="foto">

                    <!-- preview  -->
                    <img id="preview" class="mb-3"
                        style="display:none; margin: 10px auto; width: 200px; height: auto; border-radius: 6px;"
                        alt="Preview da foto">
                </div>

                <div class="d-flex gap-2 mt-3 justify-content-end">
                    <input type="reset" class="btn btn-azul" value="Limpar">
                    <a href="index.php" class="btn btn-secondary">Cancelar</a>
                    <input type="submit" class="btn btn-dark" value="Salvar">
                </div>

            </form>
        </div>
    </main>

    <footer class="footer" id="sec-info">

        <div class="footer-top">

            <div class="footer-logo">
                <img src="img/logo.png" alt="logo">
            </div>

            <div class="footer-info">
                <h4>Beatriz Andrade Vasconcelos</h4>
                <h4>Gustavo Freitas Pereira</h4>
            </div>

        </div>

        <hr>

        <div class="footer-bottom">
            © Cadastros dos Médicos - 2026
        </div>

    </footer>

    <script>
        document.getElementById('foto').addEventListener('change', function (e) {
            const file = e.target.files[0];

            if (file) {
                const reader = new FileReader();

                reader.onload = function (event) {
                    const img = document.getElementById('preview');
                    img.src = event.target.result;
                    img.style.display = 'block';
                };

                reader.readAsDataURL(file);
            }
        });
    </script>

    <script src="js/bootstrap.bundle.min.js"></script>

</body>

</html>