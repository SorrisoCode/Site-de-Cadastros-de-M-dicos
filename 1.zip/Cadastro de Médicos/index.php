<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Médicos</title>

    <link rel="icon" type="image/icon" href="img/icon.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/estilo.css">

    <style>
        .foto {
            width: 90px;
        }
    </style>
</head>

<body>

    <header class="topo container-fluid px-lg-5 px-3">

        <div class="marca d-flex align-items-center">
            <a href="#greys">
                <img src="img/logo.png" alt="Logo" class="logo img-fluid">
            </a>
        </div>

        <nav class="d-flex align-items-center flex-wrap justify-content-center">
            <a href="#sec-pesquisa">Pesquisar</a>
            <a href="#sec-lista">Cadastrados</a>
            <a href="#sec-info">Informações</a>

            <a class="btn-nav" href="https://en.wikipedia.org/wiki/Grey%27s_Anatomy">
                SAIBA MAIS
            </a>
        </nav>

    </header>

    <div class="container-fluid p-3 mb-2 breadcrumb-container">

        <nav aria-label="breadcrumb" id="greys">
            <ol class="breadcrumb fs-5">

                <li class="breadcrumb-item">
                    <a href="index.php">Início</a>
                </li>

                <li class="breadcrumb-item">
                    <a href="incluir.php">Incluir</a>
                </li>

            </ol>
        </nav>

    </div>

    <main class="container" id="sec-inicio">

        <h3>Listagem Geral de Médicos</h3>

        <!-- BARRA DE PESQUISA -->
        <div id="sec-pesquisa" class="row align-items-center mb-3 barra-acoes">

            <div class="col-md-6 text-start">

                <form action="" method="post"
                    class="d-inline-flex align-items-center">

                    <label for="busca" class="me-2">
                        Pesquisar:
                    </label>

                    <input type="search"
                        id="busca"
                        name="filtro"
                        maxlength="50"
                        placeholder="Digite o nome ou parte dele"
                        class="form-control me-2"
                        style="width: 350px;">

                    <input type="submit"
                        value="Pesquisar"
                        class="btn btn-secondary">

                </form>

            </div>

            <div class="col-md-6 text-end d-flex justify-content-end align-items-center">
                <a href="incluir.php" class="btn btn-azul btn-incluir">
                    Incluir
                </a>
            </div>

        </div>

        <?php

        try {

            include "conexao.php";

            if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST["filtro"])) {

                $filtro = "%" . $_POST["filtro"] . "%";

                $sql = "SELECT * FROM tabelaimg
                        WHERE produto LIKE ?
                        ORDER BY produto";

                $query = $conexao->prepare($sql);
                $query->bind_param("s", $filtro);
                $query->execute();

                $resultado = $query->get_result();

            } else {

                $sql = "SELECT * FROM tabelaimg ORDER BY produto";
                $resultado = $conexao->query($sql);
            }

            echo <<<HTML
<div id="sec-lista">
    <div class="table-responsive">
        <table class="table table-neutro table-light">
            <tr>
                <th width="30px">Id</th>
                <th width="100px">Código</th>
                <th width="250px">Médico</th>
                <th width="100px">Salário</th>
                <th width="100px">Imagem</th>
                <th width="100px">Ações</th>
            </tr>
HTML;

            while ($dados = $resultado->fetch_assoc()) {

                $id = base64_encode($dados['id']);

                if (empty($dados['imagem'])) {
                    $imagem = "SemImagem.png";
                } else {
                    $imagem = $dados['imagem'];
                }

                echo "<tr>";

                echo "<td class='centraliza'>{$dados['id']}</td>";
                echo "<td>{$dados['codigo']}</td>";
                echo "<td>{$dados['produto']}</td>";

                echo "<td>R$ " . number_format($dados['valor'], 2, ',', '.') . "</td>";

                echo "<td>
                        <a href='visualizar.php?id=$id' title='Visualizar médico'>
                            <img src='img/$imagem' class='foto img-thumbnail shadow' style='cursor:pointer;'>
                        </a>
                      </td>";

                echo "<td>
                        <div class='acoes'>

                            <a href='visualizar.php?id=$id'
                               class='btn btn-secondary btn-sm'>
                                Visualizar
                            </a>

                            <a href='editar.php?id=$id'
                               class='btn btn-azul btn-sm'>
                                Editar
                            </a>

                            <a href='#'
                               class='btn btn-dark btn-sm'
                               data-bs-toggle='modal'
                               data-bs-target='#excluirModal'
                               data-produto='$id'>
                                Apagar
                            </a>

                        </div>
                      </td>";

                echo "</tr>";
            }

            echo "</table></div></div>";

        } catch (Exception $e) {

            echo "<div class='alert alert-danger'>
                    {$e->getMessage()}
                  </div>";
        }

        ?>

    </main>

    <footer class="footer" id="sec-info">

        <div class="footer-top">

            <div class="footer-logo">
                <img src="img/logo.png" alt="logo">
            </div>

            <div class="footer-info">
                <h4>Beatriz Andrade Vasconcelos</h4>
                <h4>Gustavo Freitas Pereira</h4>
            </div>

        </div>

        <hr>

        <div class="footer-bottom">
            © Cadastros dos Médicos - 2026
        </div>

    </footer>

    <?php include "modal.php"; ?>

    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/dialogo.js"></script>

</body>

</html>